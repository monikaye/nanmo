<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Http\Requests\FuserInsertRequest;
class FuserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {   
        $info = DB::table('ly_admin_fuser')
                        ->select()
                        ->orderBy('id',' desc')
                        ->get();

        
        return view("Admin.Fuser.index", ['info' => $info]);
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    //展示添加页面
    public function create()
    {   
        //加载添加模板
        return view("Admin.Fuser.add");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // 执行放单人添加
    public function store(FuserInsertRequest $request)
    {   
        //获取要添加得数据
        $data                = $request->input();
        $data['create_time'] = time();
        $data['userid']      = DB::table('ly_admin_user')
                                        ->where('username','=', session('username'))
                                        ->value('id');
        $log                 = [];
        $log['remark']       = '添加了1个放单人'.$request->input('username');
        $log['create_time']  = $data['create_time'];
        $log['userid']       = $data['userid'];
        // var_dump($data);exit;
        // 执行添加
        if (DB::table("ly_admin_fuser")->insert($data)) {
            DB::table('ly_admin_log')->insert($log);
            return redirect("/fuser")->with("success","添加成功");
        } else {
            return redirect("/fuser/create")->with("error","添加失败");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        
        //获取当前的数据
        $info=DB::table("ly_admin_fuser")->where("id","=",$id)->first();
        
        //展示分类修改页面
        return view("Admin.Fuser.edit",["info"=>$info]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        $log                = [];
        $log['remark']      = '修改了1个放单人'.$request->input('username');
        $log['create_time'] = time();
        $log['userid']      = DB::table('ly_admin_user')
                                        ->where('username','=', session('username'))
                                        ->value('id');
        //获取要修改得数据
        $data = $request->except('_method');
        //执行修改
        if (DB::table("ly_admin_fuser")->where("id",$id)->update($data)) {
            DB::table('ly_admin_log')->insert($log);
            return redirect("/fuser")->with("success","修改成功");
        } else {
            return redirect("/fuser/edit/{$id}")->with("error","修改失败");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {   
        $name               = DB::table('ly_admin_fuser')
                                        ->where('id','=', $id)
                                        ->value('username');
        $log                = [];
        $log['remark']      = '删除了1个放单人'.$name;
        $log['create_time'] = time();
        $log['userid']      = DB::table('ly_admin_user')
                                        ->where('username','=', session('username'))
                                        ->value('id');
        //删除刷单任务表
        if (DB::table("ly_admin_fuser")->where("id","=",$id)->delete()){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/fuser")->with("success","删除成功");
        } else {
            return redirect("/fuser")->with("error","删除失败");
        }
        
    }
}
