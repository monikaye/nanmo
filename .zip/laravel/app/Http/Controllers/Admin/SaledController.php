<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Http\Requests\SaledInsertRequest;
class SaledController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {   
        $info = DB::table('ly_admin_saled as sa')
                        ->join('ly_admin_shop as sh',  'sa.shopid', '=' , 'sh.id')
                        ->join('ly_admin_phone as p',  'sa.phoneid', '=' , 'p.id')
                        ->join('ly_admin_fuser as f',  'sa.fuserid', '=', 'f.id')
                        ->select('sa.wxname', 'sa.why', 'sa.hap_time', 'sa.result', 'sa.smoney', 'p.phonenum', 'sh.shopname', 'f.username', 'sa.create_time', 'sa.id')
                        ->orderBy('hap_time',' desc')
                        ->get();

        // var_dump($info);
        // exit;
        return view("Admin.Saled.index", ['info' => $info]);
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    //展示添加页面
    public function create()
    {   
        //获取要添加的数据选项
        //获取店铺
        $shop  = DB::table("ly_admin_shop") 
                        -> select('shopname','id') 
                        -> get();
        //获取手机
        $phone = DB::table("ly_admin_phone") 
                        -> select('phonenum','id') 
                        -> get();
        //获取放单人
        $fuser = DB::table("ly_admin_fuser") 
                        -> select('username','id') 
                        -> get();
        //加载添加模板
        return view("Admin.Saled.add", ['shop' => $shop, 'phone' => $phone, 'fuser' => $fuser]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // 执行日常刷单任务添加
    public function store(SaledInsertRequest $request)
    {   
        //获取要添加得数据
        $data                = $request->input();
        $data['create_time'] = time();
        $data['userid']      = DB::table('ly_admin_user')
                                    ->where('username','=', session('username'))
                                    ->value('id');
        $log                 = [];
        $log['remark']       = '添加了1条售后信息';
        $log['create_time']  = $data['create_time'];
        $log['userid']       = $data['userid'];
        // var_dump($data);
        // exit;
        // 执行添加
        if (DB::table("ly_admin_saled")->insert($data)){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/saled")->with("success","添加成功");
        } else {
            return redirect("/saled/create")->with("error","添加失败");
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        
        //获取当前的数据
        $info  = DB::table("ly_admin_saled")
                        ->where("id","=",$id)
                        ->first();
        //获取店铺
        $shop  = DB::table("ly_admin_shop") 
                        ->select('shopname','id') 
                        ->get();
        //获取手机
        $phone = DB::table("ly_admin_phone") 
                        ->select('phonenum','id') 
                        ->get();
        //获取放单人
        $fuser = DB::table("ly_admin_fuser") 
                        ->select('username','id') 
                        ->get();
        //展示分类修改页面
        return view("Admin.Saled.edit",["info"=>$info, 'shop' => $shop, 'phone' => $phone, 'fuser' => $fuser]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        $log                = [];
        $log['remark']      = '修改了1条售后信息';
        $log['create_time'] = time();
        $log['userid']      = DB::table('ly_admin_user')
                                    ->where('username','=', session('username'))
                                    ->value('id');
        //获取要修改得数据
        $data               = $request->except('_method');
        //执行修改
        if (DB::table("ly_admin_huohao")->where("id",$id)->update($data)){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/huohao")->with("success","修改成功");
        } else {
            return redirect("/huohao/edit/{$id}")->with("error","修改失败");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $log                = [];
        $log['remark']      = '删除了1个售后信息';
        $log['create_time'] = time();
        $log['userid']      = DB::table('ly_admin_user')
                                    ->where('username','=', session('username'))
                                    ->value('id');
        //删除刷单任务表
        if (DB::table("ly_admin_huohao")->where("id","=",$id)->delete()){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/huohao")->with("success","删除成功");
        } else {
            return redirect("/huohao")->with("error","删除失败");
        }
        
    }
}
