<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Http\Requests\HuohaoInsertRequest;
class HuohaoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {   
        $info = DB::table('ly_admin_huohao as h')
                         ->join('ly_admin_shop as s', 'h.shopid', '=', 's.id')
                         ->select('h.huohao', 'h.zmoney', 's.shopname', 'h.create_time', 'h.id as hid')
                         ->orderBy('h.id',' desc')
                         ->get();

        
        return view("Admin.Huohao.index", ['info' => $info]);
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    //展示添加页面
    public function create()
    {   
        //获取要添加的数据选项
        //获取店铺
        $shop = DB::table("ly_admin_shop") 
                         ->select('shopname','id') 
                         ->get();
        //加载添加模板
        return view("Admin.Huohao.add", ['shop' => $shop] );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // 执行日常刷单任务添加
    public function store(HuohaoInsertRequest $request)
    {   
        //获取要添加得数据
        $data                = $request->input();
        $data['create_time'] = time();
        $log                 = [];
        $log['remark']       = '添加了1个货号'.$request->input('username');
        $log['create_time']  = $data['create_time'];
        $log['userid']       = DB::table('ly_admin_user')
                                        ->where('username','=', session('username'))
                                        ->value('id');
        // 执行添加
        if(DB::table("ly_admin_huohao")->insert($data)){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/huohao")->with("success","添加成功");
        }else{
            return redirect("/huohao/create")->with("error","添加失败");
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        
        //获取当前的数据
        $info = DB::table("ly_admin_huohao")
                         ->where("id","=",$id)
                         ->first();
        //获取店铺
        $shop = DB::table("ly_admin_shop") 
                         ->select('shopname','id') 
                         ->get();
        
        //展示分类修改页面
        return view("Admin.Huohao.edit",["info"=>$info, 'shop' => $shop]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        $log                = [];
        $log['remark']      = '修改了1个货号'.$request->input('username');
        $log['create_time'] = time();
        $log['userid']      = DB::table('ly_admin_user')
                                       ->where('username','=', session('username'))
                                       ->value('id');
        //获取要修改得数据
        $data=$request->except('_method');
        //执行修改
        if (DB::table("ly_admin_huohao")->where("id",$id)->update($data)){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/huohao")->with("success","修改成功");
        } else {
            return redirect("/huohao/edit/{$id}")->with("error","修改失败");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $huohao             = DB::table('ly_admin_huohao')
                                        ->where('id','=', $id)
                                        ->value('username');
        $log                = [];
        $log['remark']      = '删除了1个货号'.$huohao;
        $log['create_time'] = time();
        $log['userid']      = DB::table('ly_admin_user')
                                        ->where('username','=', session('username'))
                                        ->value('id');
        //删除刷单任务表
        if (DB::table("ly_admin_huohao")->where("id","=",$id)->delete()){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/huohao")->with("success","删除成功");
        } else {
            return redirect("/huohao")->with("error","删除失败");
        }
        
    }
}
