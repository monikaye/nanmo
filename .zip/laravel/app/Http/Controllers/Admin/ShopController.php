<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Http\Requests\ShopInsertRequest;
class ShopController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {   
        $info = DB::table('ly_admin_shop')
                    ->select()
                    ->orderBy('id',' desc')
                    ->paginate(10);
        
        return view("Admin.Shop.index", ['info' => $info, 'request' => $request->all()]);
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    //展示添加页面
    public function create()
    {   
        //加载添加模板
        return view("Admin.Shop.add");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // 执行店铺添加
    public function store(ShopInsertRequest $request)
    {   
        //获取要添加得数据
        $data                = $request->input();
        $data['create_time'] = time();
        $data['userid']      = DB::table('ly_admin_user')
                                     ->where('username','=', session('username'))
                                     ->value('id');
        $log                 = [];
        $log['remark']       = '添加了1个店铺:'.$request->input('shopname');
        $log['create_time']  = $data['create_time'];
        $log['userid']       = $data['userid'];
        // var_dump($data);exit;
        // 执行添加
        if (DB::table("ly_admin_shop")->insert($data)){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/shop")->with("success","添加成功");
        } else {
            return redirect("/shop/create")->with("error","添加失败");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        
        //获取当前的数据
        $info = DB::table("ly_admin_shop")
                        ->where("id","=",$id)
                        ->first();
        
        //展示分类修改页面
        return view("Admin.Shop.edit",["info"=>$info]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        $log                = [];
        $log['remark']      = '修改了1个店铺'.$request->input('shopname');
        $log['create_time'] = time();
        $log['userid']      = DB::table('ly_admin_user')
                                    ->where('username','=', session('username'))
                                    ->value('id');
        //获取要修改得数据
        $data               = $request->except('_method');
        //执行修改
        if (DB::table("ly_admin_shop")->where("id",$id)->update($data)){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/shop")->with("success","修改成功");
        } else {
            return redirect("/shop/edit/{$id}")->with("error","修改失败");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {   
        $shop               = DB::table('ly_admin_shop')
                                    ->where('id','=', $id)
                                    ->value('shopname');
        $log                = [];
        $log['remark']      = '删除了1个店铺:'.$shop;
        $log['create_time'] = time();
        $log['userid']      = DB::table('ly_admin_user')
                                    ->where('username','=', session('username'))
                                    ->value('id');
        //删除刷单任务表
        if (DB::table("ly_admin_shop")->where("id","=",$id)->delete()){
            DB::table('ly_admin_log')->insert($log);
            return redirect("/shop")->with("success","删除成功");
        } else {
            return redirect("/shop")->with("error","删除失败");
        }
        
    }
}
