<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Http\Requests\ShopInsertRequest;
class LogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {   
        // if($request->ajax()){
            // return 666;
        // }
        $info = DB::table('ly_admin_log')
                    ->select()
                    ->orderBy('create_time',' desc')
                    ->paginate(15);
        foreach ($info as $k => $v) {
            $info[$k]->userid = DB::table('ly_admin_user')
                                    ->where('id', '=', $v->userid)
                                    ->value('username');
        }
        
        return view("Admin.Log.index", ['info' => $info, 'request' => $request->all()]);
    }
    
    
}
