<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//登陆
Route::get('/login',"Admin\LoginController@login");
Route::post('/dologin',"Admin\LoginController@dologin");
Route::get('/outlogin',"Admin\LoginController@outlogin");
//主页
Route::get('/',"Admin\AdminController@index")->middleware('adminlogin');
Route::get('/index',"Admin\AdminController@index")->middleware('adminlogin');
//任务管理
Route::resource("/member","Admin\MemberController")->middleware('adminlogin');
Route::post("/memb","Admin\MemberController@index")->middleware('adminlogin');
Route::post("/daoru","Admin\MemberController@daoru")->middleware('adminlogin');
Route::get("/dao","Admin\MemberController@dao");
Route::post("/daochu","Admin\MemberController@daochu");
Route::get("/page_pro","Admin\MemberController@page_pro");
Route::get("/del","Admin\MemberController@del");



//手机管理
Route::resource("/phones","Admin\PhonesController")->middleware('adminlogin');
Route::post("/pho","Admin\PhonesController@index")->middleware('adminlogin');
Route::resource("/phone","Admin\PhoneController")->middleware('adminlogin');
//银行卡管理
Route::resource("/card","Admin\CardController")->middleware('adminlogin');
//商店管理
Route::resource("/shop","Admin\ShopController")->middleware('adminlogin');
//放单人管理
Route::resource("/fuser","Admin\FuserController")->middleware('adminlogin');
//制度值日表
Route::resource("/zhidu","Admin\ZhiController")->middleware('adminlogin');
Route::get("/zhidus","Admin\ZhiController@zhidu")->middleware('adminlogin');
//店铺汇总表
Route::get('/szhidu',"Admin\ZhiController@szhidu")->middleware('adminlogin');
Route::post('/szhidu',"Admin\ZhiController@szhidu")->middleware('adminlogin');
Route::get('/shopdaochu',"Admin\ZhiController@shopdaochu");
Route::post('/doshopdaochu',"Admin\ZhiController@doshopdaochu");
//货号管理
Route::resource("/huohao","Admin\HuohaoController")->middleware('adminlogin');
//售后管理
Route::resource("/saled","Admin\SaledController")->middleware('adminlogin');

//角色分配
Route::get("/rolelist/{id}","Admin\RolelistController@rolelist")->middleware('adminlogin');
//保存角色
Route::post("/saverole","Admin\RolelistController@saverole")->middleware('adminlogin');
//角色管理
Route::resource("/role","Admin\RolelistController")->middleware('adminlogin');
//分配权限
Route::get("/auth/{id}","Admin\RolelistController@auth")->middleware('adminlogin');
//保存权限
Route::post("/saveauth","Admin\RolelistController@saveauth")->middleware('adminlogin');
//节点管理
Route::resource("/node","Admin\NodeController")->middleware('adminlogin');

//管理员用户管理
Route::resource("/user","Admin\UserController")->middleware('adminlogin');
//日志管理
Route::resource("/log","Admin\LogController")->middleware('adminlogin');
// Route::get("/log","Admin\LogController@index");
//银行卡充值管理
Route::resource("/addcard","Admin\AddCardController")->middleware('adminlogin');










