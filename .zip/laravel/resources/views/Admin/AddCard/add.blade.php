
<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Add
                </div>
                @if(count($errors)>0)
                    @foreach ($errors->all() as $error)
                    <div class="mws-form-message error">
                            {{ $error }}
                     </div>
                    @endforeach
                @endif
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <form role="form"  method="post" enctype="multipart/form-data">

                                <div class="form-group">
                                    <label>卡号</label>
                                    <select class="form-control" name="cardid">
                                        <option value="">请选择</option>
                                        @foreach($card as $v)
                                        <option value="{{$v->id}}">{{$v->number}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>充值金额</label>
                                    <input class="form-control" type="text" name="addmoney"/>
                                </div>
                                <div class="form-group">
                                    <label>备注</label>
                                    <input class="form-control" type="text" name="remark"/>
                                </div>
                                <!-- 
                                <div class="form-group">
                                    <label>File input</label>
                                    <input type="file">
                                </div>
                                 -->
                                 {{csrf_field()}}
                                <a  class="btn " >添加</a>
                                <!-- <button type="reset" class="btn btn-default">Reset Button</button> -->
                            </form>
                        </div>
                        <script>
                        // alert($);
                            $('.btn').click(function(){

                                alert($);
                                

                                
                            });
                        </script>
                        
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
</div>


@section('title','银行卡充值')