@extends("Admin.AdminPublic.adminpublic")
@section("admin")
<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>售后信息</h2>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>微信备注</th>
                                    <th>所在手机编号</th>
                                    <th>原因</th>
                                    <th>店铺名</th>
                                    <th>发生日期</th>
                                    <th>放单人</th>
                                    <th>处理结果</th>
                                    <th>赔偿金额</th>
                                    <th>添加时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
								@foreach($info as $value)
                                <tr class="odd gradeX">
									
                                    <td>{{$value->wxname}}</td>
                                    <td>{{$value->phonenum}}</td>
                                    <td>{{$value->why}}</td>
                                    <td>{{$value->shopname}}</td>
                                    <td>{{$value->hap_time}}</td>
                                    <td>{{$value->username}}</td>
                                    <td>{{$value->result}}</td>
                                    <td>{{$value->smoney}}</td>
                                    <td><?php echo date('Y-m-d',$value->create_time) ?></td>
                                    <td>
                                    	<form action="/saled/{{$value->id}}" method="post" class="btn">
							                <button class="btn btn-danger">删除</button>{{csrf_field()}}{{method_field("DELETE")}}
							            </form>
                                        <a href="/saled/{{$value->id}}/edit" class="btn btn-info">修改</a>
                                    </td>
                                    
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
</div>
                <!-- /. ROW  -->
@endsection
@section('title','售后')