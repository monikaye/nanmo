


@extends("Admin.AdminPublic.adminpublic")
@section("admin")
<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Edit
                </div>
                @if(count($errors)>0)
                    @foreach ($errors->all() as $error)
                    <div class="mws-form-message error">
                            {{ $error }}
                     </div>
                    @endforeach
                @endif
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <form role="form"  action="/saled/{{$info->id}}" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>微信备注</label>
                                    <input class="form-control" type="text" name="wxname" placeholder="{{$info->wxname}}"  />
                                </div>
                                <div class="form-group">
                                    <label>所在手机编号</label>
                                    <select class="form-control" name="phoneid">
                                        @foreach($phone as $values)
                                        <option value="{{$values->id}}" @if($values->id==$info->phoneid) selected @endif >{{$values->phonenum}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>原因</label>
                                    <input class="form-control" type="text" name="why" placeholder="{{$info->why}}"/>
                                </div>
                                <div class="form-group">
                                    <label>店铺名</label>
                                    <select class="form-control" name="shopid">
                                        @foreach($shop as $val)
                                        <option value="{{$val->id}}"  @if($val->id==$info->shopid) selected @endif>{{$val->shopname}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>发生日期</label>
                                    <input class="form-control" type="text" name="hap_time" placeholder="{{$info->hap_time}}"/>
                                </div>
                                <div class="form-group">
                                    <label>放单人</label>
                                    <select class="form-control" name="fuserid">
                                        @foreach($fuser as $f)
                                        <option value="{{$f->id}}"  @if($f->id==$info->fuserid) selected @endif>{{$f->username}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>处理结果</label>
                                    <select class="form-control" name="result">
                                        <option value="1" @if($info->result==1) selected @endif >处理成功</option>
                                        <option value="2" @if($info->result==2) selected @endif>处理中</option>
                                        <option value="3" @if($info->result==3) selected @endif>处理失败</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>赔偿金额</label>
                                    <input class="form-control" type="text" name="smoney" placeholder="{{$info->smoney}}"/>
                                </div>
                                
                                
                                <!-- 
                                <div class="form-group">
                                    <label>File input</label>
                                    <input type="file">
                                </div>
                                 -->
                                 {{method_field("PUT")}}
                                 {{csrf_field()}}
                                <button type="submit" class="btn btn-default">修改</button>
                                <!-- <button type="reset" class="btn btn-default">Reset Button</button> -->
                            </form>
                        </div>
                        
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
</div>

@endsection
@section('title','手机卡修改')