                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>操作</th>
                                	<th>排序</th>
                                    <th>微信备注名</th>
                                    <th>所在手机编号</th>
                                    <th>旺旺号</th>
                                    <th>订单号</th>
                                    <th>淘气值</th>            
                                    <th>店铺名称</th>
                                    <th>性别</th>
                                    <th>偏远地区</th>
                                    <th>付款金额</th>
                                    <th>超级会员</th>
                                    <th>佣金</th>
                                    <th>礼物</th>
                                    <th>放单人</th>
                                    <th>绩效</th>
                                    <th>货号</th>
                                    <th>备注</th>
                                    <th>付款手机</th>
                                    <th>额外付款金额</th>
                                    <th>录入人</th>
                                    <th>试用日期</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <?php $cc = 1; ?>
                            <tbody>
								@foreach($data as $value)
                                <tr class="odd gradeX">
                                    <td><input type="checkbox" name='check' value="{{$value->id}}"></td>
									<td><?php echo $cc++; ?></td>
                                    <td>{{$value->username}}</td>
                                    <td>{{$value->pnum}}</td>
                                    <td>{{$value->wwname}}</td>
                                    <td>{{$value->orders}}</td>
                                    <td>{{$value->tqnum}}</td>
                                    <td>{{$value->shopname}}</td>
                                    @if($value->sex==1)
                                    <td>男</td>
                                    @elseif($value->sex == 2)
                                    <td>女</td>
				                    @elseif($value->sex == 3)
                                    <td>未知</td>
				   @elseif($value->sex == 0)
                                    <td>未知</td>
									@endif
                                    @if($value->ifyuan==1)
                                    <td>是</td>
                                    @elseif($value->ifyuan == 2)
                                    <td>不是</td>
				                    @elseif($value->ifyuan == 3)
                                    <td>未知</td>
						   @elseif($value->ifyuan == 0)
                                    <td>未知</td>
									@endif
                                    <td>{{$value->fmoney}}</td>
									@if($value->ifsuper == 1)
                                    <td>是</td>
                                    @elseif($value->ifsuper == 2)
                                    <td>不是</td>
				                    @elseif($value->ifsuper == 3)
                                    <td>未知</td>
				    @elseif($value->ifsuper == 0)
                                    <td>未知</td>
									@endif
                                    <td>{{$value->ymoney}}</td>
                                    <td>{{$value->gift}}</td>
                                    <td>{{$value->fname}}</td>
                                    <td>{{$value->jixiao}}</td>
                                    <td>{{$value->huohao}}</td>
                                    <td>{{$value->remark}}</td>
                                    <td>{{$value->ppnum}}</td>
                                    <td>{{$value->extra}}</td>
                                    <td>{{$value->uname}}</td>
                                    <td>{{$value->shuadan_time}}</td>
                                    <td>
                                    	<form action="/member/{{$value->id}}" method="post">
							                <button class="btn btn-danger">删除</button>{{csrf_field()}}{{method_field("DELETE")}}
							            </form>
							            <a href="/member/{{$value->id}}/edit" class="btn btn-info">修改</a>
                                    </td>
                                    
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <a class="btn btn-danger shanchu">删除</a><br>
                        <form action="/daoru" onSubmit="return confirm('您确定要导入？');" method="post" enctype="multipart/form-data" class='daodao btn'>
                            <label><input type="file" name='file[]' multiple="true"></label>
                            <!-- <label  style="width: 70%;">
                                <input type="file" value="" name="goods_img[]" style="width: 40%;height: 30px;" id="goods_img" multiple="true">
                            </label> -->
                            {{csrf_field()}}
                            <button type="submit" class="btn btn-info daoru">导入</button>
                            

                        </form>
                        <a href="/dao" class="btn btn-info">导出</a>
                        
                    </div>
                    <a href="javascript:void(0)" onclick="page(<?php echo $prev ?>)" class="btn btn-info"><<</a>
                    @if($sums <= 10)
                        @foreach($pp as $key=>$val)
                            @if($val == $page)
                            {{$val}}
                            @else
                            <a href="javascript:void(0)" onclick="page({{$val}})">{{$val}}</a>
                            @endif
                        @endforeach
                    @else
                        
                            @if($page<=3)
                                @if($page==1)
                                1
                                @else
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                @endif
                                @if($page==2)
                                2
                                @else
                                <a href="javascript:void(0)" onclick="page(2)">2</a>
                                @endif
                                @if($page==3)
                                3
                                @else
                                <a href="javascript:void(0)" onclick="page(3)">3</a>
                                @endif
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)">{{$sums}}</a>
                            @elseif($page>3 && ($sums-$page) >=3)
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $prev ?>)"><?php echo $prev; ?></a>
                                {{$page}}
                                
                                <a href="javascript:void(0)" onclick="page(<?php echo $next ?>)"><?php echo $next; ?></a>
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)">{{$sums}}</a>
                            @elseif(($sums-$page) <3)
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                <a href="javascript:void(0)">...</a>
                                @if($page==($sums-2))
                                    {{$sums-2}}
                                @else
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums-2 ?>)">{{$sums-2}}</a>
                                @endif
                                @if($page==($sums-1))
                                    {{$sums-1}}
                                @else
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums-1 ?>)">{{$sums-1}}</a>
                                @endif
                                @if($page==$sums)
                                    {{$sums}}
                                @else
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)">{{$sums}}</a>
                                @endif
                            @endif
                            
                    @endif
                    
    

                    <a href="javascript:void(0)" onclick="page(<?php echo $next ?>)" class="btn btn-info">>></a>
                    <script>

                            $('.shanchu').click(function(){
                                var a = '';
                                $('input[type=checkbox]:checked').each(function(){
                                    a = $(this).attr('value') + ',' + a;
                                });
                                del = $('input[type=checkbox]:checked');
                                // alert(a);
                                $.ajax({
                                    type:"get",
                                    url:"/del",
                                    data:{
                                    a:a,
                                },
                                success:function(msg){
                                        if(msg){
                                            // $(".panel-body").html(msg)
                                            del.parent().parent().remove();
                                        }else {
                                            
                                            alert('请选择要删除的对象');
                                        }
                                    }
                                })
                            });

                    </script>


