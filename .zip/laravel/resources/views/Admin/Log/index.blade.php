

<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>日志</h2>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>录入人</th>
                                    <th>操作</th>
                                    <th>添加时间</th>
                                </tr>
                            </thead>
                            <tbody>
								@foreach($info as $value)
                                <tr class="odd gradeX">
									
                                    <td>{{$value->userid}}</td>
                                    <td>{{$value->remark}}</td>
                                    <td><?php echo date('Y-m-d',$value->create_time) ?></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
			{!!$info->appends($request)->render()!!}

                    </div>
                    
                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
</div>
                <!-- /. ROW  -->

@section('title','日志')