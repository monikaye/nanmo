
<div class="content-boxs">
    <div class="login_content" >
        
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/OrderAdmin/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/order.png" height="100" />
                <div>订单管理-商家</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Wx_manage/Subscribe">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/caiwu.png" height="100" />
                <div>预约管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Member/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/huiyuan.png" height="100" />
                <div>会员管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/mianliao/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/ml.png" height="100" />
                <div>面料管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/SellerFinance/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/caiwu.png" height="100" />
                <div>财务管理-商家</div>
            </a>
       
        <!--  供应商的订单：role_id =2(工厂接单员) & role_id=5(面料员) -->
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/OrderProvider/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/order.png" height="100" />
                <div>订单管理-供应商</div>
            </a>
        <!--   供应商的订单 end -->
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/WxTraderMember/LoginTrader">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/caiwu.png" height="100" />
                <div>分销商管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Goods/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/goods.png" height="100" />
                <div>商品管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Goods/cate">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/seach.png" height="100" />
                <div>商品分类</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Provider/seller">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/seller.png" height="100" />
                <div>商家管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Provider/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/business.png" height="100" />
                <div>供应商管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/AdminFinance/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/caiwu.png" height="100" />
                <div>财务管理-平台</div>
            </a>
            <a class="login_content_box" href="">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/baobiao.png" height="100" />
                <div>报表</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/PDesign/index2">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/design.png" height="100" />
                <div>个性设计</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/DDesign/index2">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/design.png" height="100" />
                <div>深度设计</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Size/index">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/baobiao.png" height="100" />
                <div>规格表</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Member/AdminList">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/baobiao.png" height="100" />
                <div>账号管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/SellerFinance/tx_rec">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/baobiao.png" height="100" />
                <div>提现管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Wx_manage/Advert">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/baobiao.png" height="100" />
                <div>微信广告位管理</div>
            </a>
            <a class="login_content_box" href="http://admin.tailor-mall.com/index.php/Wx_manage/Navigation">
                <img src="http://admin.tailor-mall.com/public/liuwei/img/baobiao.png" height="100" />
                <div>微信详情管理</div>
            </a>
    </div>
</div>
<script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
    document.title='导航页';
</script>
</body>

</html>