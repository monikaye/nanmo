<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Edit
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <form role="form"  action="/node/<?php echo e($node->id); ?>" method="post" enctype="multipart/form-data">
                                
                                <div class="form-group">
                                    <label>节点名</label>
                                    <input class="form-control" type="text" name="shopname" value='<?php echo e($node->name); ?>'/>
                                </div>
                                <div class="form-group">
                                    <label>控制器</label>
                                    <input class="form-control" type="text" name="mname" value='<?php echo e($node->mname); ?>'/>
                                </div>
                                <div class="form-group">
                                    <label>方法</label>
                                    <input class="form-control" type="text" name="aname" value='<?php echo e($node->aname); ?>'/>
                                </div>
                                <div class="form-group">
                                    <label>状态</label>
                                    <select class="form-control" name="status">
                                        <option value="0" <?php if($node->status == 0): ?> selected <?php endif; ?>>开启</option>
                                        <option value="1" <?php if($node->status == 1): ?> selected <?php endif; ?>>关闭</option>
                                    </select>
                                </div>
                                <!-- 
                                <div class="form-group">
                                    <label>File input</label>
                                    <input type="file">
                                </div>
                                 -->
                                 <?php echo e(method_field("PUT")); ?>

                                 <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-default">修改</button>
                                <!-- <button type="reset" class="btn btn-default">Reset Button</button> -->
                            </form>
                        </div>
                        
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','节点修改'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>