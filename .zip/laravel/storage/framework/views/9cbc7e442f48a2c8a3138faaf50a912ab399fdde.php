<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="http://www.jinling.com/public/liuwei/css/reset.css" type="text/css" />
    <link rel="stylesheet" href="http://www.jinling.com/public/liuwei/css/pc.css" type="text/css" />
    <link rel="stylesheet" href="http://www.jinling.com/public/liuwei/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://www.jinling.com/public/liuwei/css/ace.min.css" />
    <title>金领后台管理</title>
</head>
<!--<div class="login_bg">
    <div class="login_main">
        <p><span>登录名：</span><input type="text"  name="user_name" id="user_name"/></p>
        <p><span>密码&nbsp;&nbsp;&nbsp;&nbsp;：</span><input type="password"  name="user_password" id="user_password"/></p>
        <div>
            <a href="" id="admin_login" class="login_btn">登录</a>
        </div>
    </div>
</div>-->

<body class="login-layout" > 
<div class="logintop">
    <span>欢迎后台管理界面平台</span>
    <ul>
        <li><a href="#">返回首页</a></li>
        <li><a href="#">帮助</a></li>
        <li><a href="#">关于</a></li>
    </ul>
</div>
<div class="loginbody">
    <div class="login-container">
        <div class="center">
            <h1>
                <i class="icon-leaf green"></i>
                <span class="orange">金领科技</span>
                <span class="white">后台管理系统</span>
            </h1>
            <h4 class="white">Background Management System</h4>
        </div>

        <div class="space-6"></div>

        <div class="position-relative">
            <div id="login-box" class="login-box widget-box no-border visible">
                <div class="widget-body">
                    <div class="widget-main">
                        <h4 class="header blue lighter bigger">
                            <i class="icon-coffee green"></i>
                            管理员登陆
                        </h4>

                        <div class="login_icon"><img src="http://www.jinling.com/public/liuwei/img/login.png"/></div>

                        <form class="">
                            <fieldset>
                                <label class="block clearfix">
                                                        <span class="block input-icon input-icon-right">
                                                            <input id="user_name" type="text" class="form-control"
                                                                   placeholder="登录名" name="user_name">
                                                            <i class="icon-user"></i>
                                                        </span>
                                </label>

                                <label class="block clearfix">
                                                        <span class="block input-icon input-icon-right">
                                                            <input id="user_password" type="password" class="form-control"
                                                                   placeholder="密码" name="user_password">
                                                            <i class="icon-lock"></i>
                                                        </span>
                                </label>

                                <div class="space"></div>

                                <div class="clearfix">
                                    <label class="inline">
                                        <input type="checkbox" class="ace">
                                        <span class="lbl">保存密码</span>
                                    </label>

                                    <button type="button" class="width-35 pull-right btn btn-sm btn-primary"
                                            id="admin_login" style="margin-top: -6px;  border-color: #00a0e9;">
                                        <i class="icon-key"></i>
                                        登陆
                                    </button>
                                </div>

                                <div class="space-4"></div>
                            </fieldset>
                        </form>

                    </div>

                    <div class="toolbar clearfix">


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script src="http://cdn.static.runoob.com/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src='/public/layer/layer.js'></script>
<script>
    var height =$("html ").height();
    $("body").height(height);
    $("#admin_login").click(function(){
        //alert(1);
        //return;
        var user_password = $("#user_password").val();
        var user_name = $("#user_name").val();
        var flag=1;
        if(user_password=='' || user_name==''){
            flag=0;
            alert('账户信息请填写完整!');
        }

        if(flag==1){
            $.ajax({
                type:"GET",
                url:'http://www.jinling.com/index.php/Welcome/checkAdminInfor',
                data:{user_password:user_password,user_name:user_name},
                success: function(data,textStatus){
                    // var info = jQuery.parseJSON(data);
                    // if(info.flag==1){
                    if(data==1){
                        layer.alert(info.mess);
                        location.href = 'http://www.jinling.com/index.php/Index/index';
                    }else{
                        alert(data);
                        // alert(info.mess);
                    }
                }
            });
        }
        return false;
    });
</script>

</html>