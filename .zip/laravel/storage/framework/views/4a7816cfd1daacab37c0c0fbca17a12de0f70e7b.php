
<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    导出
                </div>
                <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mws-form-message error">
                            <?php echo e($error); ?>

                     </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="panel-body">
                    <div class="row">
                        <form action="/doshopdaochu" method="post" enctype="multipart/form-data">
                        <div class="col-lg-12">
                            <label>放单日期</label>
                            <label>
                                <input type="search" class="form-control input-sm date" placeholder='开始:20180911' value="" name='start'>
                            </label>
                            <label>
                                <input type="search" class="form-control input-sm date" placeholder='结束:20180911' value="" name='stop'>
                            </label>
                            <label>
                                <select class="form-control input-sm" name="shopid">
                                    <option value="">请选择店铺</option>
                                    <?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($values->id); ?>"><?php echo e($values->shopname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            
                            </label>
                            
                            <br>
                            <label>选择要导出的字段</label><br>
                            
                            <label class="checkbox-inline">
                                <input type="checkbox" name='1' value="shopid">店铺名
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" name='2' value="f">本金
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" name='3' value="y">礼品红包
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" name='4' value="huohao">操作费
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" name='5' value="num">单数
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" name='6' value="cou">应收款
                            </label>
                            
                            <label class="checkbox-inline">
                                <input type="checkbox" name='7' value="shuadan_time">刷单日期
                            </label><br><br><br><br><br><br>
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-info">导出</button>
                        </div>
                        </form>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','店铺汇总导出'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>