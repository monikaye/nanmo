<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Edit
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <form role="form"  action="/saled/<?php echo e($info->id); ?>" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>微信备注</label>
                                    <input class="form-control" type="text" name="wxname" placeholder="<?php echo e($info->wxname); ?>"  />
                                </div>
                                <div class="form-group">
                                    <label>所在手机编号</label>
                                    <select class="form-control" name="phoneid">
                                        <option value="0">请选择</option>
                                        <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($values->id); ?>" <?php if($values->id==$info->phoneid): ?> selected <?php endif; ?> ><?php echo e($values->phonenum); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>原因</label>
                                    <input class="form-control" type="text" name="why" placeholder="<?php echo e($info->why); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>店铺名</label>
                                    <select class="form-control" name="shopid">
                                        <option value="0">请选择</option>
                                        <?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val->id); ?>"  <?php if($val->id==$info->shopid): ?> selected <?php endif; ?>><?php echo e($val->shopname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>发生日期</label>
                                    <input class="form-control" type="text" name="hap_time" placeholder="<?php echo e($info->hap_time); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>放单人</label>
                                    <select class="form-control" name="fuserid">
                                        <option value="0">请选择</option>
                                        <?php $__currentLoopData = $fuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($f->id); ?>"  <?php if($f->id==$info->fuserid): ?> selected <?php endif; ?>><?php echo e($f->username); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>处理结果</label>
                                    <select class="form-control" name="result">
                                        <option value="1" <?php if($info->result==1): ?> selected <?php endif; ?> >处理成功</option>
                                        <option value="2" <?php if($info->result==2): ?> selected <?php endif; ?>>处理中</option>
                                        <option value="3" <?php if($info->result==3): ?> selected <?php endif; ?>>处理失败</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>赔偿金额</label>
                                    <input class="form-control" type="text" name="smoney" placeholder="<?php echo e($info->smoney); ?>"/>
                                </div>
                                
                                
                                <!-- 
                                <div class="form-group">
                                    <label>File input</label>
                                    <input type="file">
                                </div>
                                 -->
                                 <?php echo e(method_field("PUT")); ?>

                                 <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-default">修改</button>
                                <!-- <button type="reset" class="btn btn-default">Reset Button</button> -->
                            </form>
                        </div>
                        
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','手机卡修改'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>