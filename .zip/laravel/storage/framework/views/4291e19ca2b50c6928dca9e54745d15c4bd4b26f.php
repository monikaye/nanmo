<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>日常刷单任务表</h2>
                </div>
                <div id="dataTables-example_filter" class="dataTables_filter" >
                    <form action="/memb"  method="post" enctype="multipart/form-data" style="padding:15px;">
                        <label>淘气的值</label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='大于' value="<?php echo e(isset($map[1][2]) ? $map[1][2] : ''); ?>" name='bigt'>
                        </label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='小于' value="<?php echo e(isset($map[2][2]) ? $map[2][2] : ''); ?>" name='smallt'>
                        </label>
                        <label>
                            <select class="form-control input-sm" name="phoneid">
                                <option value="">所在手机编号</option>
                                <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $va): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($va->id); ?>" <?php if($va->id==session('phoneid')): ?> selected <?php endif; ?> ><?php echo e($va->phonenum); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label>备注名</label>
                        <label>
                            <input type="search" class="form-control input-sm date" value="" name='username'>
                        </label>
                       <label>付款金额</label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='大于' value="<?php echo e(isset($map[13][2]) ? $map[13][2] : ''); ?>" name='bigf'>
                        </label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='小于' value="<?php echo e(isset($map[14][2]) ? $map[14][2] : ''); ?>" name='smallf'>
                        </label>
                        <label>
                            <select class="form-control" name="ifsuper">
                                    <option value="">是否超级会员</option>
                                    <option value="1" <?php if(session('ifsuper')==1): ?> selected <?php endif; ?>>是</option>
                                    <option value="2" <?php if(session('ifsuper')==2): ?> selected <?php endif; ?>>不是</option>
                                    <option value="3" <?php if(session('ifsuper')==3): ?> selected <?php endif; ?>>未知</option>
                            </select>
                        </label>
                        <label>礼物&nbsp;&nbsp;&nbsp;</label>
                        <label>
                            <input type="search" class="form-control input-sm date" value="" name='gift'>
                        </label>
                        <br>
                        <label>佣金金额</label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='大于' value="<?php echo e(isset($map[5][2]) ? $map[5][2] : ''); ?>" name='bigy'>
                        </label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='小于' value="<?php echo e(isset($map[6][2]) ? $map[6][2] : ''); ?>" name='smally'>
                        </label>
                        <label>
                            <select class="form-control" name="ifyuan">
                                    <option value="">是否偏远地区</option>
                                    <option value="1" <?php if(session('ifyuan')==1): ?> selected <?php endif; ?>>是</option>
                                    <option value="2" <?php if(session('ifyuan')==2): ?> selected <?php endif; ?>>不是</option>
                                    <option value="3" <?php if(session('ifyuan')==3): ?> selected <?php endif; ?>>未知</option>
                            </select>
                        </label>
                        <label>旺旺号</label>
                        <label>
                            <input type="search" class="form-control input-sm date" value="" name='wwname'>
                        </label>
                        <label>额外付款</label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='大于' value="<?php echo e(isset($map[17][2]) ? $map[17][2] : ''); ?>" name='bige'>
                        </label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='小于' value="<?php echo e(isset($map[18][2]) ? $map[18][2] : ''); ?>" name='smalle'>
                        </label>
                        <label>
                            <select class="form-control input-sm" name="fuserid">
                                <option value="">请选择放单人</option>
                                <?php $__currentLoopData = $fuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->fid); ?>" <?php if($value->fid==session('fuserid')): ?> selected <?php endif; ?>><?php echo e($value->fname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label>备注&nbsp;&nbsp;&nbsp;&nbsp;</label>
                        <label>
                            <input type="search" class="form-control input-sm date" value="" name='remark'>
                        </label>
                        <br>
                        <label>绩效金额</label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='大于' value="<?php echo e(isset($map[9][2]) ? $map[9][2] : ''); ?>" name='bigj'>
                        </label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='小于' value="<?php echo e(isset($map[10][2]) ? $map[10][2] : ''); ?>" name='smallj'>
                        </label>
                        <label>
                            <select class="form-control input-sm" name="fphone">
                                <option value="">付款手机编号</option>
                                <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($vc->id); ?>"  <?php if($vc->id==session('fphone')): ?> selected <?php endif; ?>><?php echo e($vc->phonenum); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label>订单号</label>
                        <label>
                            <input type="search" class="form-control input-sm date" value="<?php echo e(isset($map[12][2]) ? $map[12][2] : ''); ?>" name='orders'>
                        </label>
                        <label>放单日期</label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='开始:20180911' value="<?php echo e(isset($map[21][2]) ? $map[21][2] : ''); ?>" name='start'>
                        </label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='结束:20180911' value="<?php echo e(isset($map[22][2]) ? $map[22][2] : ''); ?>" name='stop'>
                        </label>
                        <label>
                            <select class="form-control input-sm" name="sex">
                                <option value="">性别</option>
                                <option value="1" <?php if(session('sex')==1): ?> selected <?php endif; ?>>男</option>
                                <option value="2"<?php if(session('sex')==2): ?> selected <?php endif; ?>>女</option>
                                <option value="3"<?php if(session('sex')==3): ?> selected <?php endif; ?>>未知</option>
                            </select>
                        </label>
                        <label>
                            <select class="form-control input-sm" name="huohao">
                                <option value="">货号</option>
                                <?php $__currentLoopData = $huohao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($val->id); ?>" <?php if($val->id==session('huohao')): ?> selected <?php endif; ?>><?php echo e($val->huohao); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <br>
                        <label>
                            <select class="form-control input-sm">
                                <option value="">店铺列表</option>
                                <?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ve->id); ?>" <?php if($ve->id==session('shopid')): ?> selected <?php endif; ?>><?php echo e($ve->shopname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label>
                            <input type="search" class="form-control input-sm date" placeholder='店铺名' name='shopid'>
                        </label>
                         
                        <label>
                            <?php echo e(csrf_field()); ?>

                            <input type="submit" class="form-control input-sm date"  value='搜索'>
                        </label>
                    </form>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>排序</th>
                                    <th>微信备注名</th>
                                    <th>所在手机编号</th>
                                    <th>旺旺号</th>
                                    <th>订单号</th>
                                    <th>淘气值</th>            
                                    <th>店铺名称</th>
                                    <th>性别</th>
                                    <th>偏远地区</th>
                                    <th>付款金额</th>
                                    <th>超级会员</th>
                                    <th>佣金</th>
                                    <th>礼物</th>
                                    <th>放单人</th>
                                    <th>绩效</th>
                                    <th>货号</th>
                                    <th>备注</th>
                                    <th>付款手机</th>
                                    <th>额外付款金额</th>
                                    <th>录入人</th>
                                    <th>刷单日期</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <?php $cc = 1; ?>
                            <tbody>
								<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX">
									<td><?php echo $cc++; ?></td>
                                    <td><?php echo e($value->username); ?></td>
                                    <td><?php echo e($value->pnum); ?></td>
                                    <td><?php echo e($value->wwname); ?></td>
                                    <td><?php echo e($value->orders); ?></td>
                                    <td><?php echo e($value->tqnum); ?></td>
                                    <td><?php echo e($value->shopname); ?></td>
                                    <?php if($value->sex==1): ?>
                                    <td>男</td>
                                    <?php elseif($value->sex == 2): ?>
                                    <td>女</td>
				                    <?php elseif($value->sex == 3): ?>
                                    <td>未知</td>
									<?php endif; ?>
                                    <?php if($value->ifyuan==1): ?>
                                    <td>是</td>
                                    <?php elseif($value->ifyuan == 2): ?>
                                    <td>不是</td>
				                    <?php elseif($value->ifyuan == 3): ?>
                                    <td>未知</td>
									<?php endif; ?>
                                    <td><?php echo e($value->fmoney); ?></td>
									<?php if($value->ifsuper == 1): ?>
                                    <td>是</td>
                                    <?php elseif($value->ifsuper == 2): ?>
                                    <td>不是</td>
				                    <?php elseif($value->ifsuper == 3): ?>
                                    <td>未知</td>
									<?php endif; ?>
                                    <td><?php echo e($value->ymoney); ?></td>
                                    <td><?php echo e($value->gift); ?></td>
                                    <td><?php echo e($value->fname); ?></td>
                                    <td><?php echo e($value->jixiao); ?></td>
                                    <td><?php echo e($value->huohao); ?></td>
                                    <td><?php echo e($value->remark); ?></td>
                                    <td><?php echo e($value->ppnum); ?></td>
                                    <td><?php echo e($value->extra); ?></td>
                                    <td><?php echo e($value->uname); ?></td>
                                    <td><?php echo e($value->shuadan_time); ?></td>
                                    <td>
                                    	<form action="/member/<?php echo e($value->id); ?>" method="post">
							                <button class="btn btn-danger">删除</button><?php echo e(csrf_field()); ?><?php echo e(method_field("DELETE")); ?>

							            </form>
							            <a href="/member/<?php echo e($value->id); ?>/edit" class="btn btn-info">修改</a>
                                    </td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <form action="/daoru" onSubmit="return confirm('您确定要导入？');" method="post" enctype="multipart/form-data" class='daodao btn'>
                            <label><input type="file" name='file[]' multiple="true"></label>
                            <!-- <label  style="width: 70%;">
                                <input type="file" value="" name="goods_img[]" style="width: 40%;height: 30px;" id="goods_img" multiple="true">
                            </label> -->
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-info daoru">导入</button>
                            

                        </form>
                        <a href="/dao" class="btn btn-info">导出</a><br>
                    </div>

                    <a href="javascript:void(0)" onclick="page(<?php echo $prev ?>)" class="btn btn-info"><<</a>
                    <?php if($sums <= 10): ?>
                        <?php $__currentLoopData = $pp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($val == $page): ?>
                            <?php echo e($val); ?>

                            <?php else: ?>
                            <a href="javascript:void(0)" onclick="page(<?php echo e($val); ?>)"><?php echo e($val); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        
                            <?php if($page<=3): ?>
                                <?php if($page==1): ?>
                                1
                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                <?php endif; ?>
                                <?php if($page==2): ?>
                                2
                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(2)">2</a>
                                <?php endif; ?>
                                <?php if($page==3): ?>
                                3
                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(3)">3</a>
                                <?php endif; ?>
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)"><?php echo e($sums); ?></a>
                            <?php elseif($page>3 && ($sums-$page) >=3): ?>
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $prev ?>)"><?php echo $prev; ?></a>
                                <?php echo e($page); ?>

                                
                                <a href="javascript:void(0)" onclick="page(<?php echo $next ?>)"><?php echo $next; ?></a>
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)"><?php echo e($sums); ?></a>
                            <?php elseif(($sums-$page) <3): ?>
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                <a href="javascript:void(0)">...</a>
                                <?php if($page==($sums-2)): ?>
                                    <?php echo e($sums-2); ?>

                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums-2 ?>)"><?php echo e($sums-2); ?></a>
                                <?php endif; ?>
                                <?php if($page==($sums-1)): ?>
                                    <?php echo e($sums-1); ?>

                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums-1 ?>)"><?php echo e($sums-1); ?></a>
                                <?php endif; ?>
                                <?php if($page==$sums): ?>
                                    <?php echo e($sums); ?>

                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)"><?php echo e($sums); ?></a>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                    <?php endif; ?>
                    <a href="javascript:void(0)" onclick="page(<?php echo $next ?>)" class="btn btn-info">>></a>
                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
        <script src="/Admin/assets/js/jquery-1.8.3.min.js"></script>
        <script>
            $('.daoru').click(function(){

                setTimeout(function(){
                // $('.daodao').attr('onsubmit','return false');
                    // alert("导入中")
                    $('.daoru').attr('disabled','true');
                    // $(this).parentNode.submit();
                },100);

            });


             function page(page){
                // alert(page);
                $.ajax({
                    type:"get",
                    url:"/page_pro",
                    data:{
                    page:page,
                },
                success:function(msg){
                        if(msg){
                            $(".panel-body").html(msg)
                        }else {
                            
                            alert('无输出');
                        }
                    }
                })
            }   
        </script>
        
</div>
                <!-- /. ROW  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','日常刷单任务表'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>