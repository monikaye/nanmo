
<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>节点信息</h2>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>节点ID</th>
                                    <th>节点名</th>
                                    <th>控制器</th>
                                    <th>方法</th>
                                    <th>状态</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
								    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr> 
                                        <td><?php echo e($row->id); ?></td> 
                                        <td><?php echo e($row->name); ?></td> 
                                        <td><?php echo e($row->mname); ?></td> 
                                        <td><?php echo e($row->aname); ?></td>
                                        <?php if($row->status==1): ?>
                                        <td>开启</td> 
                                        <?php elseif($row->status==2): ?>
                                        <td>关闭</td> 
                                        <?php endif; ?> 
                                        <td>
                                           <a href="/node/<?php echo e($row->id); ?>" class="btn btn-danger">分配权限</a>
                                           <form action="/role/<?php echo e($row->id); ?>" method="post" class="btn">
                                                <?php echo e(method_field("DELETE")); ?> <?php echo e(csrf_field()); ?>

                                                <button class="btn btn-success del" name="<?php echo e($row->id); ?>">删除</button>
                                           </form> 
                                            <a href="/node/<?php echo e($row->id); ?>/edit" class="btn btn-info">修改</a>
                                        </td>
                                   </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo $data->appends($request)->render(); ?>

                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
</div>
                <!-- /. ROW  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','节点表'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>