<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Add
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <form role="form"  action="/saverole" method="post" enctype="multipart/form-data">

                                <div class="form-group">
                                    <label>角色信息</label>
                                    <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="rids[]" value="<?php echo e($row->id); ?>" <?php if(in_array($row->id,$rids)): ?>checked <?php endif; ?>> <?php echo e($row->name); ?>

                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    
                                </div>
                                <!-- 
                                <div class="form-group">
                                    <label>File input</label>
                                    <input type="file">
                                </div>
                                 -->
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="uid" value="<?php echo e($info->id); ?>">
                                <button type="submit" class="btn ">分配角色</button>
                                <!-- <button type="reset" class="btn btn-default">Reset Button</button> -->
                            </form>
                        </div>
                        
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','角色信息'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>