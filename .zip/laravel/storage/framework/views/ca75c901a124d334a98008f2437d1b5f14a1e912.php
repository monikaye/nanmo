
<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>角色列表</h2>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>角色名</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
							<?php $__currentLoopData = $datal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr> 
                                <td><?php echo e($row->id); ?></td> 
                                <td><?php echo e($row->name); ?></td> 
                                <td>
                                  <a href="/auth/<?php echo e($row->id); ?>" class="btn btn-danger">分配权限</a>
                                  <form action="/role/<?php echo e($row->id); ?>" method="post" class="btn">
                                        <?php echo e(method_field("DELETE")); ?> <?php echo e(csrf_field()); ?>

                                        <button class="btn btn-success del" name="<?php echo e($row->id); ?>">删除</button>
                                  </form> 
                                        <a href="/role/<?php echo e($row->id); ?>/edit" class="btn btn-info">修改</a>
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
</div>
                <!-- /. ROW  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','角色列表'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>