
<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>售后信息</h2>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>微信备注</th>
                                    <th>所在手机编号</th>
                                    <th>原因</th>
                                    <th>店铺名</th>
                                    <th>发生日期</th>
                                    <th>放单人</th>
                                    <th>处理结果</th>
                                    <th>赔偿金额</th>
                                    <th>添加时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX">
									
                                    <td><?php echo e($value->wxname); ?></td>
                                    <td><?php echo e($value->phonenum); ?></td>
                                    <td><?php echo e($value->why); ?></td>
                                    <td><?php echo e($value->shopname); ?></td>
                                    <td><?php echo e($value->hap_time); ?></td>
                                    <td><?php echo e($value->username); ?></td>
                                    <td><?php echo e($value->result); ?></td>
                                    <td><?php echo e($value->smoney); ?></td>
                                    <td><?php echo date('Y-m-d',$value->create_time) ?></td>
                                    <td>
                                    	<form action="/saled/<?php echo e($value->id); ?>" method="post" class="btn">
							                <button class="btn btn-danger">删除</button><?php echo e(csrf_field()); ?><?php echo e(method_field("DELETE")); ?>

							            </form>
                                        <a href="/saled/<?php echo e($value->id); ?>/edit" class="btn btn-info">修改</a>
                                    </td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
</div>
                <!-- /. ROW  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','售后'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>