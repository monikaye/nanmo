                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                	<th>排序</th>
                                    <th>微信备注名</th>
                                    <th>所在手机编号</th>
                                    <th>旺旺号</th>
                                    <th>订单号</th>
                                    <th>淘气值</th>            
                                    <th>店铺名称</th>
                                    <th>性别</th>
                                    <th>偏远地区</th>
                                    <th>付款金额</th>
                                    <th>超级会员</th>
                                    <th>佣金</th>
                                    <th>礼物</th>
                                    <th>放单人</th>
                                    <th>绩效</th>
                                    <th>货号</th>
                                    <th>备注</th>
                                    <th>付款手机</th>
                                    <th>额外付款金额</th>
                                    <th>录入人</th>
                                    <th>刷单日期</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <?php $cc = 1; ?>
                            <tbody>
								<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX">
									<td><?php echo $cc++; ?></td>
                                    <td><?php echo e($value->username); ?></td>
                                    <td><?php echo e($value->pnum); ?></td>
                                    <td><?php echo e($value->wwname); ?></td>
                                    <td><?php echo e($value->orders); ?></td>
                                    <td><?php echo e($value->tqnum); ?></td>
                                    <td><?php echo e($value->shopname); ?></td>
                                    <?php if($value->sex==1): ?>
                                    <td>男</td>
                                    <?php elseif($value->sex == 2): ?>
                                    <td>女</td>
				                    <?php elseif($value->sex == 3): ?>
                                    <td>未知</td>
									<?php endif; ?>
                                    <?php if($value->ifyuan==1): ?>
                                    <td>是</td>
                                    <?php elseif($value->ifyuan == 2): ?>
                                    <td>不是</td>
				                    <?php elseif($value->ifyuan == 3): ?>
                                    <td>未知</td>
									<?php endif; ?>
                                    <td><?php echo e($value->fmoney); ?></td>
									<?php if($value->ifsuper == 1): ?>
                                    <td>是</td>
                                    <?php elseif($value->ifsuper == 2): ?>
                                    <td>不是</td>
				                    <?php elseif($value->ifsuper == 3): ?>
                                    <td>未知</td>
									<?php endif; ?>
                                    <td><?php echo e($value->ymoney); ?></td>
                                    <td><?php echo e($value->gift); ?></td>
                                    <td><?php echo e($value->fname); ?></td>
                                    <td><?php echo e($value->jixiao); ?></td>
                                    <td><?php echo e($value->huohao); ?></td>
                                    <td><?php echo e($value->remark); ?></td>
                                    <td><?php echo e($value->ppnum); ?></td>
                                    <td><?php echo e($value->extra); ?></td>
                                    <td><?php echo e($value->uname); ?></td>
                                    <td><?php echo e($value->shuadan_time); ?></td>
                                    <td>
                                    	<form action="/member/<?php echo e($value->id); ?>" method="post">
							                <button class="btn btn-danger">删除</button><?php echo e(csrf_field()); ?><?php echo e(method_field("DELETE")); ?>

							            </form>
							            <a href="/member/<?php echo e($value->id); ?>/edit" class="btn btn-info">修改</a>
                                    </td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <form action="/daoru" method="post" enctype="multipart/form-data" class='btn'>
                            <label><input type="file" name='file'></label>
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-info">导入</button>
                        </form>
                        <a href="/dao" class="btn btn-info">导出</a>
                        
                    </div>
                    <a href="javascript:void(0)" onclick="page(<?php echo $prev ?>)" class="btn btn-info"><<</a>
                    <?php if($sums <= 10): ?>
                        <?php $__currentLoopData = $pp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($val == $page): ?>
                            <?php echo e($val); ?>

                            <?php else: ?>
                            <a href="javascript:void(0)" onclick="page(<?php echo e($val); ?>)"><?php echo e($val); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        
                            <?php if($page<=3): ?>
                                <?php if($page==1): ?>
                                1
                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                <?php endif; ?>
                                <?php if($page==2): ?>
                                2
                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(2)">2</a>
                                <?php endif; ?>
                                <?php if($page==3): ?>
                                3
                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(3)">3</a>
                                <?php endif; ?>
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)"><?php echo e($sums); ?></a>
                            <?php elseif($page>3 && ($sums-$page) >=3): ?>
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $prev ?>)"><?php echo $prev; ?></a>
                                <?php echo e($page); ?>

                                
                                <a href="javascript:void(0)" onclick="page(<?php echo $next ?>)"><?php echo $next; ?></a>
                                <a href="javascript:void(0)">...</a>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)"><?php echo e($sums); ?></a>
                            <?php elseif(($sums-$page) <3): ?>
                                <a href="javascript:void(0)" onclick="page(1)">1</a>
                                <a href="javascript:void(0)">...</a>
                                <?php if($page==($sums-2)): ?>
                                    <?php echo e($sums-2); ?>

                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums-2 ?>)"><?php echo e($sums-2); ?></a>
                                <?php endif; ?>
                                <?php if($page==($sums-1)): ?>
                                    <?php echo e($sums-1); ?>

                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums-1 ?>)"><?php echo e($sums-1); ?></a>
                                <?php endif; ?>
                                <?php if($page==$sums): ?>
                                    <?php echo e($sums); ?>

                                <?php else: ?>
                                <a href="javascript:void(0)" onclick="page(<?php echo $sums ?>)"><?php echo e($sums); ?></a>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                    <?php endif; ?>
                    
    

                    <a href="javascript:void(0)" onclick="page(<?php echo $next ?>)" class="btn btn-info">>></a>
                    


