<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>手机信息</h2>
                </div>
                <div class="panel-body">
                    <div id="dataTables-example_filter" class="dataTables_filter">
                        <form action="/pho"  method="post" enctype="multipart/form-data">
                            <label>发单数量</label>
                            <label>
                                <input type="search" class="form-control input-sm date" placeholder='大于' value="" name='bigd'>
                            </label>
                            <label>
                                <input type="search" class="form-control input-sm date" placeholder='小于' value="" name='smalld'>
                            </label>
                            <label>
                                <select class="form-control input-sm" name="cardid">
                                    <option value="">银行卡号</option>
                                    <?php $__currentLoopData = $card; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vs->id); ?>"><?php echo e($vs->number); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label>
                                <select class="form-control input-sm" name="phoneid">
                                    <option value="">手机编号</option>
                                    <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $va): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($va->id); ?>"><?php echo e($va->phonenum); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <br>
                            <label>发卡片量</label>
                            <label>
                                <input type="search" class="form-control input-sm date" placeholder='大于' value="" name='bigc'>
                            </label>
                            <label>
                                <input type="search" class="form-control input-sm date" placeholder='小于' value="" name='smallc'>
                            </label>
                            
                            

                            <br>
                            
                            <label>
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" class="form-control input-sm date"  value='搜索'>
                            </label>
                        </form>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>手机编号</th>
                                    <th>手机号</th>
                                    <th>微信号</th>
                                    
                                    <th>发单量</th>
                                    <th>发卡量</th>
                                    <th>银行卡号</th>
                                    <th>商家</th>
                                    
                                    <th>添加时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX">
									
                                    <td><?php echo e($pho->phonenum); ?></td>
                                    <td><?php echo e($pho->pnumber); ?></td>
                                    <td><?php echo e($pho->wxnumber); ?></td>
                                                                        <td><?php echo e($pho->countday); ?></td>
                                    <td><?php echo e($pho->fcard); ?></td>
                                    <td><?php echo e($pho->number); ?></td>
                                    <td><?php echo e($pho->shopmark); ?></td>
                                    
                                    <td><?php echo date('Y-m-d',$pho->create_time) ?></td>
                                    <td>
                                    	<form action="/phones/<?php echo e($pho->id); ?>" method="post" class='btn'>
							                <button class="btn btn-danger">删除</button><?php echo e(csrf_field()); ?><?php echo e(method_field("DELETE")); ?>

							            </form>
                                        <a href="/phones/<?php echo e($pho->id); ?>/edit" class="btn btn-info">修改</a>
                                    </td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo $info->appends($request)->render(); ?>

                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
</div>
                <!-- /. ROW  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','手机信息表'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>