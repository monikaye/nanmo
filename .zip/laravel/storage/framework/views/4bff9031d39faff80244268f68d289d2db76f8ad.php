<?php $__env->startSection("admin"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','后台首页'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>