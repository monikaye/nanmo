<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>会员列表</h2>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>账号</th>
                                    <th>名字</th>
                                    <th>手机号</th>
                                    <th>状态</th>
                                    <th>添加时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX">
									
                                    <td><?php echo e($value->username); ?></td>
                                    <td><?php echo e($value->nickname); ?></td>
                                    <td><?php echo e($value->mobile); ?></td>
                                    <?php if($value->status==1): ?>
                                    <td>开启</td>
                                    <?php elseif($value->status==2): ?>
                                    <td>关闭</td>
                                    <?php endif; ?>
                                    <td><?php echo date('Y-m-d',$value->create_time) ?></td>
                                    <td>
                                        <a href="/rolelist/<?php echo e($value->id); ?>" class="btn btn-danger">分配角色</a>
                                    	<form action="/user/<?php echo e($value->id); ?>" method="post" class='btn'>
							                <button class="btn btn-danger">删除</button><?php echo e(csrf_field()); ?><?php echo e(method_field("DELETE")); ?>

							            </form>
                                        <a href="/user/<?php echo e($value->id); ?>/edit" class="btn btn-info">修改</a>
                                    </td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
</div>
                <!-- /. ROW  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','会员列表'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>