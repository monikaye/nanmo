<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Edit
                </div>
                <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mws-form-message error">
                            <?php echo e($error); ?>

                     </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <form role="form"  action="/member/<?php echo e($info->id); ?>" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>微信备注名</label>
                                    <input class="form-control" type="text" name="username" value="<?php echo e($info->username); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>手机编号</label>
                                    <select class="form-control" name="phoneid">
                                        <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>" <?php if($info->phoneid==$value->id): ?> selected <?php endif; ?>><?php echo e($value->phonenum); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>刷单人旺旺号</label>
                                    <input class="form-control" type="text" name="wwname"  value="<?php echo e($info->wwname); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>订单号</label>
                                    <input class="form-control" type="number" name="orders"  value="<?php echo e($info->orders); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>淘气值</label>
                                    <input class="form-control" type="number" name="tqnum"  value="<?php echo e($info->tqnum); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>货号</label>
                                    <select class="form-control" name="huohao">
                                        <?php $__currentLoopData = $huohao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val->id); ?>" <?php if($info->huohao==$val->id): ?> selected <?php endif; ?>><?php echo e($val->huohao); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>性别</label>
                                    <select class="form-control" name="sex">
                                        <option value="1" <?php if($info -> sex == 1 ): ?> selected <?php endif; ?>>男</option>
                                        <option value="2" <?php if($info -> sex == 2 ): ?> selected <?php endif; ?>>女</option>
				       <option value="3" <?php if($info -> sex == 3 ): ?> selected <?php endif; ?>>未知</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>是否偏远地区</label>
                                    <select class="form-control" name="ifyuan">
                                        <option value="1" <?php if($info -> ifyuan == 1 ): ?> selected <?php endif; ?>>是</option>
                                        <option value="2" <?php if($info -> ifyuan == 2 ): ?> selected <?php endif; ?>>不是</option>
				       <option value="3" <?php if($info -> ifyuan == 3 ): ?> selected <?php endif; ?>>未知</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>付款金额</label>
                                    <input class="form-control" type="text" name="fmoney" value="<?php echo e($info->fmoney); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>佣金</label>
                                    <input class="form-control" type="text" name="ymoney" value="<?php echo e($info->ymoney); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>是否超级会员</label>
                                    <select class="form-control" name="ifsuper">
                                        <option value="1" <?php if($info -> ifsuper == 1 ): ?> selected <?php endif; ?>>是</option>
                                        <option value="2" <?php if($info -> ifsuper == 2 ): ?> selected <?php endif; ?>>不是</option>
				       <option value="3" <?php if($info -> ifsuper == 3 ): ?> selected <?php endif; ?>>未知</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>礼物</label>
                                    <input class="form-control" type="text" name="gift" value="<?php echo e($info->gift); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>放单人</label>
                                    <input class="form-control" type="text" name="fuserid" value="<?php echo e($info->fuserid); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>绩效</label>
                                    <input class="form-control" type="text" name="jixiao" value="<?php echo e($info->jixiao); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>试用时间</label>
                                    <input class="form-control" type="number" name="shuadan_time" value="<?php echo e($info->shuadan_time); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label>备注</label>
                                    <textarea class="form-control" rows="3" name="remark" ><?php echo e($info->remark); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label>付款手机</label>
                                    <select class="form-control" name="fphone">
                                        <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>" <?php if($info->fphone==$value->id): ?> selected <?php endif; ?>><?php echo e($value->phonenum); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>额外付款金额</label>
                                    <input class="form-control" type="text" name="extra" value="<?php echo e($info->extra); ?>"/>
                                </div>
                                <!-- 
                                <div class="form-group">
                                    <label>File input</label>
                                    <input type="file">
                                </div>
                                 -->
                                 <?php echo e(method_field("PUT")); ?>

                                 <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-default">修改</button>
                                <!-- <button type="reset" class="btn btn-default">Reset Button</button> -->
                            </form>
                        </div>
                        
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','日常试用任务修改'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>