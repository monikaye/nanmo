<?php $__env->startSection("admin"); ?>
<div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-heading">
                     <h2>手机信息</h2>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>手机编号</th>
                                    <th>手机号码</th>
                                    <th>微信号</th>
                                    
                                    <th>微信零钱余额</th>
				   <th>银行卡主</th>            
                                    <th>关联银行卡号</th>
                                    <th>卡内余额</th>
                                    <th>添加时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX">
									
                                    <td><?php echo e($value->pnum); ?></td>
                                    <td><?php echo e($value->pnumber); ?></td>
                                    <td><?php echo e($value->wxnumber); ?></td>
                                    
                                    <td><?php echo e($value->pmoney); ?></td>
				   <td><?php echo e($value->cardname); ?></td>
                                    <td><?php echo e($value->cnumber); ?></td>
                                    <td><?php echo e($value->cmoney); ?></td>
                                    <td><?php echo date('Y-m-d',$value->create_time) ?></td>
                                    <td>
                                    	<form action="/phone/<?php echo e($value->pid); ?>" method="post" class="btn">
							                <button class="btn btn-danger">删除</button><?php echo e(csrf_field()); ?><?php echo e(method_field("DELETE")); ?>

							            </form>
                                        <a href="/phone/<?php echo e($value->pid); ?>/edit" class="btn btn-info">修改</a>
                                    </td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo $info->appends($request)->render(); ?>

                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
</div>
                <!-- /. ROW  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','手机卡表'); ?>
<?php echo $__env->make("Admin.AdminPublic.adminpublic", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>